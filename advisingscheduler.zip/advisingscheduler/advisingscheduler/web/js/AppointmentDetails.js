$( "#accordion" ).accordion({ heightStyle: "content" });
