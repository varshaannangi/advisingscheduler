$("#accordion").accordion({heightStyle: "content"});

