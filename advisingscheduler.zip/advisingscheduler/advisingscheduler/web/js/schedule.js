$( "#accordion" ).accordion({ heightStyle: "content" });
//$("#submitBtn").button().click(function(){});
//$("#resetBtn").button().click(function(){});
