Creating Database
https://netbeans.org/kb/docs/ide/java-db.html#starting

Localhost node:1527
Database name: advising
User name: advising
Password: advising

If we keep the database info the same on every machine, we won't have to make changes in the code as to which server to connect to

Creating tables
https://netbeans.org/kb/docs/ide/java-db.html#using
Right click the Advising database, and connect
Open createAdvisingTables.sql
Run using netbeans, select advising database as a target